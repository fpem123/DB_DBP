import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/** 
 * @author CS 201413395 ��ȣ��
 * @Method JDBC �ǽ� 3��
 * @Info ��й�ȣ ã�� �г�
 */
@SuppressWarnings("serial")
public class SelectPanel extends JPanel{
	
	private JLabel lbId;
	private JLabel lbPassword;
	private JLabel lbName;
	private JLabel lbEmail;

	private JTextField tfId;
	private JPasswordField tfPassword;
	private JTextField tfName;
	private JTextField tfEmail;
	
	private JButton btSelect;
	private JButton btReset;
	
	private SelectPanel panel;
	
	public SelectPanel() {
		panel = this;
	
		setLayout(new GridLayout(5, 2));

		lbId = new JLabel("ID : ", JLabel.CENTER);
		lbPassword = new JLabel("Password : ", JLabel.CENTER);
		lbName = new JLabel("Name : ", JLabel.CENTER);
		lbEmail = new JLabel("E-mail : ", JLabel.CENTER);

		tfId = new JTextField();
		tfPassword = new JPasswordField();
		tfName = new JTextField();
		tfEmail = new JTextField();

		btSelect = new JButton("Select");
		btReset = new JButton("Reset");
		btSelect.addActionListener(actionListener);
		btReset.addActionListener(actionListener);
		
		add(lbId, JLabel.CENTER);
		add(tfId);
		add(lbPassword, JLabel.CENTER_ALIGNMENT);
		add(tfPassword);
		add(lbName, JLabel.CENTER_ALIGNMENT);
		add(tfName);
		add(lbEmail, JLabel.CENTER_ALIGNMENT);
		add(tfEmail);
		add(btSelect, JLabel.CENTER_ALIGNMENT);
		add(btReset);
		
		setSize(400, 200);
	}
	
	private ActionListener actionListener = new ActionListener() {
		@Override
		@SuppressWarnings("deprecation")
		public void actionPerformed(ActionEvent event) {
			Object source = event.getSource();
			if(source == btSelect) {
				Connection connection = null;
				Statement stmt = null;
				ResultSet rs = null;
				
				try {
					connection = DatabaseManager.getConnection();
					if(connection != null) {
						stmt = connection.createStatement();
						String sql = "SElECT * " +
								"FROM member " +
								"WHERE Id = '" + tfId.getText() + 
								"' and Password = '" + tfPassword.getText() + "'";				
						rs = stmt.executeQuery(sql);
						
						if(rs.next()) {
							JOptionPane.showMessageDialog(panel, "select success");
							tfName.setText(rs.getString("Name"));
							tfEmail.setText(rs.getString("Email"));
						}
						else
							JOptionPane.showMessageDialog(panel, "select fail");
					}
				}catch(SQLException e) {
					e.printStackTrace();
				}finally {
					try {
						if(stmt != null) stmt.close();
						if(connection != null) connection.close();
					}catch (Exception ee) {
						ee.printStackTrace();
					}
				}
			}else if(source == btReset) {
				reset();
			}
			
		}
	};
	
	private void reset() {
		tfId.setText("");
		tfPassword.setText("");
		tfName.setText("");
		tfEmail.setText("");
	}
}

