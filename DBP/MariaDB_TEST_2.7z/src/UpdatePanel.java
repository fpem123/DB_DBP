import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/** 
 * @author CS 201413395 ��ȣ��
 * @Method JDBC �ǽ� 3��
 * @Info ȸ������ ������Ʈ �г�
 */
@SuppressWarnings("serial")
public class UpdatePanel extends JPanel{
	
	private JLabel lbClass;
	private JLabel lbCondition;
	private JLabel lbChange;
	private JLabel lbId;
	private JLabel lbPassword;
	private JLabel lbName;
	private JLabel lbEmail;
	private JLabel lbNothing;
	
	private JTextField tfId;
	private JTextField tfId_new;
	private JPasswordField tfPassword;
	private JPasswordField tfPassword_new;
	private JTextField tfName;
	private JTextField tfName_new;
	private JTextField tfEmail;
	private JTextField tfEmail_new;

	private JButton btUpdate;
	private JButton btReset;
	
	private UpdatePanel panel;
	
	public UpdatePanel() {
		panel = this;
		
		setLayout(new GridLayout(6, 3));

		lbId = new JLabel("ID : ", JLabel.CENTER);
		lbPassword = new JLabel("Before Password : ", JLabel.CENTER);
		lbName = new JLabel("Name : ", JLabel.CENTER);
		lbEmail = new JLabel("Email : ", JLabel.CENTER);
		lbClass = new JLabel("���� ", JLabel.CENTER);
		lbCondition = new JLabel("����", JLabel.CENTER);
		lbChange = new JLabel("�ٲܰ�", JLabel.CENTER);
		lbNothing = new JLabel("", JLabel.CENTER);

		tfId = new JTextField();
		tfPassword = new JPasswordField();
		tfName = new JTextField();
		tfEmail = new JTextField();

		tfId_new = new JTextField();
		tfPassword_new = new JPasswordField();
		tfName_new = new JTextField();
		tfEmail_new = new JTextField();

		btUpdate = new JButton("Update");
		btReset = new JButton("Reset");
		btUpdate.addActionListener(actionListener);
		btReset.addActionListener(actionListener);
		
		add(lbClass, JLabel.CENTER);
		add(lbCondition, JLabel.CENTER_ALIGNMENT);
		add(lbChange, JLabel.CENTER_ALIGNMENT);
		add(lbId, JLabel.CENTER_ALIGNMENT);
		add(tfId);
		add(tfId_new);
		add(lbPassword, JLabel.CENTER_ALIGNMENT);
		add(tfPassword);
		add(tfPassword_new);
		add(lbName, JLabel.CENTER_ALIGNMENT);
		add(tfName);
		add(tfName_new);
		add(lbEmail, JLabel.CENTER_ALIGNMENT);
		add(tfEmail);
		add(tfEmail_new);
		add(lbNothing);
		add(btUpdate, JLabel.CENTER_ALIGNMENT);
		add(btReset);
		
		setSize(400, 200);
	}
	
	private ActionListener actionListener = new ActionListener() {
		@Override
		@SuppressWarnings("deprecation")
		public void actionPerformed(ActionEvent event) {
			Object source = event.getSource();
			if(source == btUpdate) {
				Connection connection = null;
				Statement stmt = null;
				ResultSet rs ;
				int yes;				// ���� ���θ� �ѹ� �� ����� �г�
				
				try {
					connection = DatabaseManager.getConnection();
					if(connection != null) {
						stmt = connection.createStatement();		
						yes = JOptionPane.showConfirmDialog(panel, "Are you sure?", "Confrirm", JOptionPane.YES_NO_OPTION);
						String sql = "SELECT * " +
								"FROM member " + 
								"WHERE Id = '" + tfId.getText() + 
								"' and Password = '" + tfPassword.getText() + "'";		
						rs = stmt.executeQuery(sql);
						
						if(rs == null) 	// result set�� null�̸� �߸��� ȸ������
							JOptionPane.showMessageDialog(panel, "Wrong password or not exist user");
						else if(yes == JOptionPane.YES_OPTION){		// ���� ���θ� �ѹ� ���				
							if(rs.next()) {
								JOptionPane.showMessageDialog(panel, "update success");
								
								tfName.setText(rs.getString("Name"));
								tfEmail.setText(rs.getString("Email"));
						
								sql = "Update member " + 
								"Set Id = '" + tfId_new.getText() +
								"', Password = '" + tfPassword_new.getText() + 
								"', Name = '" + tfName_new.getText() + 
								"', Email = '" + tfEmail_new.getText() + "' " + 
								"Where Id = '" + tfId.getText() + "'";
								stmt.executeUpdate(sql);		
							}
							else
								JOptionPane.showMessageDialog(panel, "update fail");
						}

					}
				}catch(SQLException e) {
					e.printStackTrace();
				}finally {
					try {
						if(stmt != null) stmt.close();
						if(connection != null) connection.close();
					}catch (Exception ee) {
						ee.printStackTrace();
					}
				}
			}else if(source == btReset) {
				reset();
			}
			
		}
	};
	
	private void reset() {
		tfId.setText("");
		tfPassword.setText("");
		tfPassword_new.setText("");
		tfEmail_new.setText("");
		tfName_new.setText("");
	}
}

