import java.sql.Connection;
import java.sql.DriverManager;


public class DatabaseManager {
	private static String className = "org.mariadb.jdbc.Driver";
	private static String url = "jdbc:mariadb://127.0.0.1:3306/mydb";	// DB url
	private static String ID = "root";									// user name
	private static String PW = "hoseop123";								// my password
	
	static {
		try {
			Class.forName(className);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static Connection getConnection() {
		Connection connection = null;
		
		try {
			connection = DriverManager.getConnection(url, ID, PW);
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return connection;
	}
}
