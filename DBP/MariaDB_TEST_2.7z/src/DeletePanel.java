import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/** 
 * @author CS 201413395 ��ȣ��
 * @Method JDBC �ǽ� 3��
 * @Info ȸ��Ż�� �г�
 */
@SuppressWarnings("serial")
public class DeletePanel extends JPanel{
	
	private JLabel lbId;
	private JLabel lbPassword;
	private JLabel lbName;
	private JLabel lbEmail;

	private JTextField tfId;
	private JPasswordField tfPassword;
	private JTextField tfName;
	private JTextField tfEmail;
	
	private JButton btDelete;
	private JButton btReset;
	
	private DeletePanel panel;
	
	public DeletePanel() {
		panel = this;
		
		setLayout(new GridLayout(5, 2));

		lbId = new JLabel("ID : ", JLabel.CENTER);
		lbPassword = new JLabel("Password : ", JLabel.CENTER);
		lbName = new JLabel("Name : ", JLabel.CENTER);
		lbEmail = new JLabel("E-mail : ", JLabel.CENTER);

		tfId = new JTextField();
		tfPassword = new JPasswordField();
		tfName = new JTextField();
		tfEmail = new JTextField();

		btDelete = new JButton("Delete");
		btReset = new JButton("Reset");
		btDelete.addActionListener(actionListener);
		btReset.addActionListener(actionListener);
		
		add(lbId, JLabel.CENTER);
		add(tfId);
		add(lbPassword, JLabel.CENTER_ALIGNMENT);
		add(tfPassword);
		add(lbName, JLabel.CENTER_ALIGNMENT);
		add(tfName);
		add(lbEmail, JLabel.CENTER_ALIGNMENT);
		add(tfEmail);
		add(btDelete, JLabel.CENTER_ALIGNMENT);
		add(btReset);
		
		setSize(400, 200);
	}
	
	private ActionListener actionListener = new ActionListener() {
		@Override
		@SuppressWarnings("deprecation")
		public void actionPerformed(ActionEvent event) {
			Object source = event.getSource();
			if(source == btDelete) {
				Connection connection = null;
				Statement stmt = null;
				ResultSet rs = null;
				int yes;				// ���� ���θ� �ѹ� �� ����� �г�
				int count = 0;
				
				try {
					connection = DatabaseManager.getConnection();
					if(connection != null) {
						stmt = connection.createStatement();
						yes = JOptionPane.showConfirmDialog(panel, "Are you sure?", "Confrirm", JOptionPane.YES_NO_OPTION);		// ���� ���� ���
						if(yes == JOptionPane.YES_OPTION) {
							String sql = "SELECT * " +
									"FROM member " +
									"WHERE Id = '" + tfId.getText() +
									"' and Password = '" + tfPassword.getText() + "'";
							rs = stmt.executeQuery(sql);
							
							sql = "DELETE " +
								"FROM member " +
								"WHERE Id = '" + tfId.getText() + "'";
							count = stmt.executeUpdate(sql);
						}
						
						if(count == 1) {
							rs.next();
							JOptionPane.showMessageDialog(panel, "delete success");
							tfName.setText(rs.getString("Name"));
							tfEmail.setText(rs.getString("Email"));
						}
						else
							JOptionPane.showMessageDialog(panel, "delete fail");
					}
				}catch(SQLException e) {
					e.printStackTrace();
				}finally {
					try {
						if(stmt != null) stmt.close();
						if(connection != null) connection.close();
					}catch (Exception ee) {
						ee.printStackTrace();
					}
				}
			}else if(source == btReset) {
				reset();
			}
			
		}
	};
	
	private void reset() {
		tfId.setText("");
		tfPassword.setText("");
		tfName.setText("");
		tfEmail.setText("");
	}
}

