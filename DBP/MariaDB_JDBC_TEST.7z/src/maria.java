import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** 
 * @author CS 201413395 ��ȣ��
 * @Method JDBC �ǽ� 1��
 */
public class maria {
	
	 /** 
	  * @param conn : <class 'Connection'> ������ DB ��ü
	  * @param sql : <class 'String'> SQL ����
	  * @return void
	  * @Method ���� : DB�� �Է¹��� select SQL ����
	  */
	private static void select(Connection conn, String sql) {
		try {
			
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				System.out.println("Bookid : " + rs.getInt("bookid") +
						", Bookname : " + rs.getString("bookname") +
						", Publisher : " + rs.getString("publisher") +  
						", Price : " + rs.getInt("price") + "��");
			}
			
			//���� ����
			stmt.close();
			
		} catch(SQLException exception) {
			
			exception.printStackTrace();
		}
	}
	
	/** 
	  * @param conn : <class 'Connection'> ������ DB ��ü
	  * @param sql : <class 'String'> SQL ����
	  * @return void
	  * @Method ���� : DB�� �Է¹��� insert SQL ����
	  */
	private static void insert(Connection conn, String sql) {
		try {
			
			Statement stmt = conn.createStatement();
			
			int count = stmt.executeUpdate(sql);
			System.out.println(count + " row inserted");
			
			//���� ����
			stmt.close();
			
		} catch(SQLException exception) {
			exception.printStackTrace();
		}
	}
	
	/** 
	  * @param conn : <class 'Connection'> ������ DB ��ü
	  * @param sql : <class 'String'> SQL ����
	  * @return void
	  * @Method ���� : DB�� �Է¹��� update SQL ����
	  */
	private static void update(Connection conn, String sql) {
		try {
			
			Statement stmt = conn.createStatement();
			
			int count = stmt.executeUpdate(sql);
			System.out.println(count + " row updated");
			
			//���� ����
			stmt.close();
			
		} catch(SQLException exception) {
			exception.printStackTrace();
		}
	}
	
	/** 
	  * @param conn : <class 'Connection'> ������ DB ��ü
	  * @param sql : <class 'String'> sql ����
	  * @return void
	  * @Method ���� : DB�� �Է¹��� delete SQL ����
	  */
	private static void delete(Connection conn, String sql) {
		try {

			Statement stmt = conn.createStatement();
			
			int count = stmt.executeUpdate(sql);
			System.out.println(count + " row deleted");
			
			//���� ����
			stmt.close();
			
		} catch(SQLException exception) {
			
			exception.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		
		String driver = "org.mariadb.jdbc.Driver";
		String url = "jdbc:mariadb://127.0.0.1:3306/mydb";		// DB url
		String user = "root";									// user name
		String pwd = "hoseop123";								// my password
		Connection conn;
		
		try {
			// Connecting mydb
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, pwd);
			System.out.println("JDBC Loaded & Connected\n");
			
			// insert
			insert(conn, "insert into book values(101, 'DBP �ǽ�', '�������б�', 35000)");
			insert(conn, "insert into book values(102, 'JDBC �ǽ�', '�������б�', 28000)");
			insert(conn, "insert into book values(103, 'DBP ������Ʈ', '�������б�', 25000)");

			select(conn, "select * from book where bookid > 100");
			
			// update
			update(conn, "update book set price=30000 where bookid=101");
			update(conn, "update book set price=20000 where bookid=102");
			update(conn, "update book set price=15000 where bookid=103");
			
			select(conn, "select * from book where bookid > 100");
			
			// delete
			delete(conn, "delete from book where bookid > 100");
			
			//���� ����
			conn.close();
			System.out.println("\nJDBC Disconnected");
			
		}catch (ClassNotFoundException | SQLException exception) {
			
			exception.printStackTrace();
		}
		
	}
}
