import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** 
 * @author CS 201413395 ��ȣ��
 * @Method JDBC �ǽ� 2��
 */
public class maria2 {
	
	
	/** 
	  * @param conn : <class 'Connection'> ������ DB ��ü
	  * @param sql : <class 'String'> SQL ����
	  * @return void
	  * @Method ���� : DB�� �Է¹��� SQL�� ���� table�� ����
	  */
	private static void createTable(Connection conn, String sql)	{
		try {
			Statement stmt = conn.createStatement();
			
			int count = stmt.executeUpdate(sql);
			
			System.out.println("Table created, " + count + " row inserted");
			
		} catch(SQLException exception) {
			
			exception.printStackTrace();
		}
	}
	
	
	/** 
	  * @param conn : <class 'Connection'> ������ DB ��ü
	  * @param table : <class 'String'> table �̸�
	  * @return void
	  * @Method ���� : �Է¹��� table�� DB���� �����Ѵ�.
	  */
	private static void dropTable(Connection conn, String table)	{
		try {
			Statement stmt = conn.createStatement();
			
			String sql = "drop table " + table;
			
			stmt.executeUpdate(sql);
			
			System.out.println(table + " Table droped");
			
		} catch(SQLException exception) {
			
			exception.printStackTrace();
		}
	}
	
	
	 /** 
	  * @param conn : <class 'Connection'> ������ DB ��ü
	  * @param sql : <class 'String'> SQL ����
	  * @return void
	  * @Method ���� : DB�� �Է¹��� select SQL ����
	  */
	private static void select(Connection conn, String sql) {
		try {
			
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			
			while (rs.next()) {
				System.out.println("Bookname : " + rs.getString("bookname") +
						", Name : " + rs.getString("name") +
						", Orderdate : " + rs.getDate("orderdate") +  
						", salePrice : " + rs.getInt("saleprice") +
						", Publisher : " + rs.getString("publisher") +
						", Price : " + rs.getInt("price"));
			}
			
			//���� ����
			stmt.close();
			
		} catch(SQLException exception) {
			
			exception.printStackTrace();
		}
	}
	
	
	
	public static void main(String[] args) {
		
		String driver = "org.mariadb.jdbc.Driver";
		String url = "jdbc:mariadb://127.0.0.1:3306/mydb";		// DB url
		String user = "root";									// user name
		String pwd = "hoseop123";								// my password
		Connection conn;
		
		try {
			// Connecting mydb
			Class.forName(driver);
			conn = DriverManager.getConnection(url, user, pwd);
			System.out.println("JDBC Loaded & Connected\n");
			
			// table ����
			createTable(conn, "create table SuperOrders as "
					+ "select bookname, name, orderdate, saleprice, publisher, price "
					+ "from	Orders "
					+ "left join Customer on Orders.custid = Customer.custid "
					+ "left join Book on Orders.bookid = Book.bookid");
			
			// select
			select(conn, "select * "
					+ "from SuperOrders "
					+ "where name = '��̶�'");
			
			// table ����
			//dropTable(conn, "SuperOrders");
			
			//���� ����
			conn.close();
			System.out.println("\nJDBC Disconnected");
			
		}catch (ClassNotFoundException | SQLException exception) {
			
			exception.printStackTrace();
		}
		
	}
	
}
